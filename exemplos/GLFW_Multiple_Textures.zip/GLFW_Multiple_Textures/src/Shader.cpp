#include "Shader.h"

Shader::Shader(const char* vertexPath, const char* fragmentPath, const char* geometryPath)
{
    //ctor
}

Shader::~Shader()
{
    //dtor
}
